<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toyota Car Investment App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            padding: 20px;
        }
        .product-item {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin: 10px 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s;
        }
        .product-item:hover {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        button {
            background-color: #4CAF50; /* Green */
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #45a049; /* Darker Green */
        }
        #login-form, #products, #product-details, #deposit-page, #withdraw-page {
            display: none;
        }
        #login-form {
            display: block; /* Show login form by default */
        }
    </style>
</head>
<body>
    <h1>Toyota Car Investment App</h1>

    <!-- Login Form -->
    <div id="login-form">
        <h2>Login</h2>
        <input type="text" id="username" placeholder="Username (0847911309)">
        <input type="password" id="password" placeholder="Password (ottobock)">
        <button onclick="login()">Login</button>
        <p id="login-error" style="color: red;"></p>
    </div>

    <!-- Products Section -->
    <div id="products">
        <h2>Available Products</h2>
        <div id="product-list"></div>
        <button onclick="withdraw()">Withdraw</button>
        <button onclick="deposit()">Deposit</button>
        <p id="balance-display"></p>
    </div>

    <!-- Product Details Page -->
    <div id="product-details" style="display:none;">
        <h2 id="product-name"></h2>
        <p id="product-daily-profit"></p>
        <p id="product-total-amount"></p>
        <p id="product-description"></p>
        <button onclick="buyProduct()">Buy Now</button>
        <button onclick="goBackToProducts()">Back to Products</button>
    </div>

    <!-- Deposit Page -->
    <div id="deposit-page" style="display:none;">
        <h2>Deposit Money</h2>
        <p>Deposit details: N.P Ndlela, Account Number: 1234567890, Tyme Bank</p>
        <p>After deposit, send proof of payment to customer care on WhatsApp.</p>
        <button onclick="goBackToProducts()">Back to Products</button>
    </div>

    <!-- Withdraw Page -->
    <div id="withdraw-page" style="display:none;">
        <h2>Withdraw Money</h2>
        <label for="withdraw-amount">Withdrawal Amount:</label>
        <input type="number" id="withdraw-amount" placeholder="Enter amount">
        <label for="bank-select">Select Bank:</label>
        <select id="bank-select">
            <option value="Capitec">Capitec</option>
            <option value="Absa">Absa</option>
            <option value="Tyme Bank">Tyme Bank</option>
            <option value="Standard Bank">Standard Bank</option>
        </select>
        <button onclick="confirmWithdrawal()">Withdraw</button>
        <button onclick="goBackToProducts()">Back to Products</button>
    </div>

    <!-- WhatsApp Button -->
    <button onclick="openWhatsApp()">Contact Customer Care on WhatsApp</button>

    <script>
        let isLoggedIn = false;
        let balance = 0;
        let selectedProduct = null;

        // User credentials for login
        const users = {
            '0847911309': 'ottobock' // Login credentials
        };

        // Product details with descriptions
        const products = [
            { 
                id: 1, 
                name: "Toyota Tazz", 
                price: 100, 
                dailyProfit: 10, 
                profitDays: 15,
                description: "The Toyota Tazz is a compact hatchback known for its reliability and fuel efficiency."
            },
            { 
                id: 2, 
                name: "Toyota Corolla", 
                price: 300, 
                dailyProfit: 30, 
                profitDays: 15,
                description: "The Toyota Corolla is a popular sedan celebrated for its dependable performance."
            },
            { 
                id: 3, 
                name: "Toyota Quantum", 
                price: 800, 
                dailyProfit: 80, 
                profitDays: 15,
                description: "The Toyota Quantum is a versatile and spacious minibus, designed for larger groups."
            },
            { 
                id: 4, 
                name: "Toyota Land Cruiser", 
                price: 1000, 
                dailyProfit: 100, 
                profitDays: 15,
                description: "The Toyota Land Cruiser is a legendary SUV renowned for its rugged capability and comfort."
            },
        ];

        // Function to handle user login
        function login() {
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;
            const loginError = document.getElementById("login-error");

            // Authentication check
            if (users[username] && users[username] === password) {
                isLoggedIn = true;
                balance = 0; // Set initial balance
                document.getElementById("login-form").style.display = "none";
                document.getElementById("products").style.display = "block";
                displayProducts(); // Show products after login
            } else {
                loginError.innerText = "Invalid username or password.";
            }
        }

        // Function to display the available products
        function displayProducts() {
            const productList = document.getElementById("product-list");
            productList.innerHTML = ""; // Clear previous entries
            products.forEach(product => {
                const productItem = document.createElement("div");
                productItem.className = "product-item";
                productItem.innerHTML = `
                    <strong>${product.name}</strong> - R${product.price} 
                    <br>Daily Profit: R${product.dailyProfit} for ${product.profitDays} days
                    <br><button onclick="viewProduct(${product.id})">View Details</button>
                `;
                productList.appendChild(productItem);
            });
            document.getElementById("balance-display").innerText = `Current Balance: R${balance}`;
        }

        // Function to view selected product details
        function viewProduct(productId) {
            selectedProduct = products.find(product => product.id === productId);
            document.getElementById("product-name").innerText = selectedProduct.name;
            document.getElementById("product-daily-profit").innerText = `Daily Profit: R${selectedProduct.dailyProfit}`;
            document.getElementById("product-total-amount").innerText = `Total Amount from Investment: R${selectedProduct.price + (selectedProduct.dailyProfit * selectedProduct.profitDays)}`;
            document.getElementById("product-description").innerText = selectedProduct.description;

            document.getElementById("products").style.display = "none";
            document.getElementById("product-details").style.display = "block";
        }

        // Function to buy a product
        function buyProduct() {
            if (balance >= selectedProduct.price) {
                balance -= selectedProduct.price;
                alert(`You have successfully purchased the ${selectedProduct.name}. Current balance: R${balance}`);
                goBackToProducts();
            } else {
                alert("Insufficient balance to buy this product.");
            }
        }

        // Function to go back to products
        function goBackToProducts() {
            document.getElementById("product-details").style.display = "none";
            document.getElementById("products").style.display = "block";
        }

        // Function to open deposit page
        function deposit() {
            document.getElementById("products").style.display = "none";
            document.getElementById("deposit-page").style.display = "block";
        }

        // Function to open withdraw page
        function withdraw() {
            document.getElementById("products").style.display = "none";
            document.getElementById("withdraw-page").style.display = "block";
        }

        // Function to confirm withdrawal
        function confirmWithdrawal() {
            const amount = parseFloat(document.getElementById("withdraw-amount").value);
            if (isNaN(amount) || amount <= 0) {
                alert("Please enter a valid amount.");
                return;
            }
            if (amount > balance) {
                alert("Insufficient balance for withdrawal.");
            } else {
                balance -= amount;
                alert(`You have successfully withdrawn R${amount}. Current balance: R${balance}`);
                goBackToProducts();
            }
        }

        // Function to go back to products from deposit page
        function goBackToDeposit() {
            document.getElementById("deposit-page").style.display = "none";
            document.getElementById("products").style.display = "block";
        }

        // Function to open WhatsApp
        function openWhatsApp() {
            const message = "Hello, I need assistance with my investment.";
            const phoneNumber = "1234567890"; // Replace with your customer care WhatsApp number
            window.open(`https://api.whatsapp.com/send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`);
        }
    </script>
</body>
</html>
let userReferralCode = 'REF123'; // Example referral code for the user
let totalInvites = 0; // Track total invites

// Function to copy the referral link to clipboard
function copyLink() {
    const link = `www.toyotainvestment.com?ref=${userReferralCode}`;
    navigator.clipboard.writeText(link).then(() => {
        alert('Referral link copied to clipboard!');
    });
}

// Function to handle user login
function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const loginError = document.getElementById("login-error");

    // Authentication check
    if (users[username] && users[username] === password) {
        isLoggedIn = true;
        balance = 0; // Set initial balance
        document.getElementById("login-form").style.display = "none";
        document.getElementById("products").style.display = "block";
        displayProducts(); // Show products after login
        document.getElementById("referral-code").innerText = userReferralCode; // Show referral code
        document.getElementById("share-link").style.display = "block"; // Show share link section
    } else {
        loginError.innerText = "Invalid username or password.";
    }
}

// Function to simulate an invite (to be called when a new user registers)
function inviteNewUser() {
    totalInvites++;
    if (totalInvites % 5 === 0) {
        balance += 30; // Reward for every 5 invites
        alert(`Congratulations! You've earned R30 for inviting ${totalInvites} users.`);
    }
    document.getElementById("total-invites").innerText = totalInvites; // Update invite count
}

// Function to view invites
function viewInvites() {
    document.getElementById("products").style.display = "none";
    document.getElementById("invite-page").style.display = "block";
    document.getElementById("total-invites").innerText = totalInvites; // Show total invites
}
