# POnzi scheme template 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Quinton-Mthembu/pen/GRVdwjw](https://codepen.io/Quinton-Mthembu/pen/GRVdwjw).

